
let alive = true;

function isBomb(number) {
    return (number >= 9) && (number <= (8 + bombCount));
}

function safeFirstClick(cell) {
    let bombs = countAdjacentBombs(cell);
    let number = getNumberForCell(cell);
    while (bombs !== 0 || isBomb(number)) {
        data = generateData(rowCount, colCount);
        bombs = countAdjacentBombs(cell);
        number = getNumberForCell(cell);
        debugLog();
    }
}

function triggerBombClicks() {
    const cells = tableBody.getElementsByTagName('td');
    for (let i = 0; i < cells.length; i++) {
        let cell = cells[i];
        if (isBomb(getNumberForCell(cell))) {
            cell.removeEventListener('click', handleCellClick);
            styleLostCell(cell);
        }
    }
}

function triggerBombClicksWin() {
    const cells = tableBody.getElementsByTagName('td');
    for (let i = 0; i < cells.length; i++) {
        let cell = cells[i];
        if (isBomb(getNumberForCell(cell))) {
            if (cell.textContent === '🚩') {
                cell.textContent = '🎉';
            } else {
                cell.textContent = '🚩';
            }
            cell.style.color = '#eeeeee';
            cell.removeEventListener('click', handleCellClick);
        }
    }
}

function countAdjacentBombs(cell) {
    const row = parseInt(cell.dataset.y);
    const col = parseInt(cell.dataset.x);
    let count = 0;
    const positions = [
        { r: -1, c: -1 }, { r: -1, c: 0 }, { r: -1, c: 1 },
        { r: 0, c: -1 }, /* center */ { r: 0, c: 1 },
        { r: 1, c: -1 }, { r: 1, c: 0 }, { r: 1, c: 1 }
    ];

    for (const pos of positions) {
        const newRow = row + pos.r;
        const newCol = col + pos.c;

        if (newRow >= 0 && newRow < rowCount && newCol >= 0 && newCol < colCount) {
            const adjNumber = data[newCol + (newRow * colCount)];
            if (isBomb(adjNumber)) {
                count++;
            }
        }
    }
    return count;
}

function uncoverSurroundingCells(cell) {
    const row = parseInt(cell.dataset.y);
    const col = parseInt(cell.dataset.x);

    const positions = [
        { r: -1, c: -1 }, { r: -1, c: 0 }, { r: -1, c: 1 },
        { r: 0, c: -1 }, /* center */ { r: 0, c: 1 },
        { r: 1, c: -1 }, { r: 1, c: 0 }, { r: 1, c: 1 }
    ];

    for (const pos of positions) {
        const newRow = row + pos.r;
        const newCol = col + pos.c;

        if (newRow >= 0 && newRow < rowCount && newCol >= 0 && newCol < colCount) {
            const adjacentCell = tableBody.rows[newRow].cells[newCol];
            if (!adjacentCell.dataset.hasClicked) {
                const adjNumber = data[newCol + (newRow * colCount)];
                if (adjNumber !== 999 && adjNumber !== 888) {
                    const bombs = countAdjacentBombs(adjacentCell);
                    cell.textContent = '';
                    adjacentCell.textContent = bombs === 0 ? ' ' : bombs;
                    adjacentCell.style.backgroundColor = '#e8e8e8';
                    adjacentCell.style.color = switchCaseColors(bombs);
                    adjacentCell.style.fontWeight = '700';
                    adjacentCell.dataset.hasClicked = 'true';
                    adjacentCell.style.cursor = 'default';
                    uncoveredCells++;
                    if (bombs === 0) {
                        uncoverSurroundingCells(adjacentCell);
                    }
                }
            }
        }
    }
}

function styleLostCell(cell) {
    cell.textContent = '💣';
    cell.style.backgroundColor = 'red';
    cell.style.color = '#eeeeee';
    cell.style.fontSize = '13px';
}

function lose(cell) {
    events.textContent = 'You clicked on a mine!';
    message.textContent = 'You lost!';
    flagCount.textContent = '';
    styleLostCell(cell);
    triggerBombClicks();
    alive = false;
}

function win() {
    events.textContent = 'You located all of the bombs!';
    message.textContent = 'You won!';
    flagCount.textContent = '';
    triggerBombClicksWin();
}

function getNumberForCell(cell) {
    const index = parseInt(cell.dataset.x) + (parseInt(cell.dataset.y) * colCount);
    return data[index];
}

function switchCaseColors(bombs) {
    switch (bombs) {
        case 1:
            return '#0000ff';
            break;
        case 2:
            return '#008000'
            break;
        case 3:
            return '#ff0000'
            break;
        case 4:
            return '#000080'
            break;
        case 5:
            return '#800000'
            break;
        case 6:
            return '#008080'
            break;
        case 7:
            return '#808080'
            break;
        case 8:
            return '#800080'
            break;
    }
}

function handleCellClick(cell) {
    if (alive) {
        clickCount++;
        if (cell.textContent === '🚩' || cell.textContent === '💣' || cell.dataset.hasClicked) {
            return;
        }

        if (clickCount === 1) {
            safeFirstClick(cell);
        }

        const number = getNumberForCell(cell);
        console.log("Cicked x=" + cell.dataset.x + " y=" + cell.dataset.y + " number=" + number);

        if (isBomb(number, bombCount)) {
            lose(cell);
            uncoveredCells = 0;
        } else if (number !== 999 && number !== 888) {
            const bombs = countAdjacentBombs(cell);
            cell.dataset.hasClicked = 'true';
            if (bombs === 0) {
                cell.textContent = '';
                uncoverSurroundingCells(cell);
            } else {
                cell.textContent = bombs;
            }
            cell.style.backgroundColor = '#e8e8e8';
            cell.style.cursor = 'default';
            cell.style.fontWeight = '700';
            cell.style.fontSize = '16px';
            cell.style.color = switchCaseColors(bombs);
            uncoveredCells++;

            console.log("Uncovered " + uncoveredCells);
            if (uncoveredCells >= ((rowCount * colCount) - bombCount)) {
                win();
            }
        }
        debugLog();
    }
}

function generateData(numRows, numCols) {
    let currentNumber = 1;
    let data = [];
    for (let y = 0; y < numRows; y++) {
        for (let x = 0; x < numCols; x++) {
            data.push(currentNumber);
            currentNumber++;
        }
    }

    for (let a = data.length - 1; a > 0; a--) {
        const b = Math.floor(Math.random() * (a + 1));
        [data[a], data[b]] = [data[b], data[a]];
    }
    return data;
}

const tableBody = document.getElementById('gameBoardBody');
const events = document.getElementById('activity');
const message = document.getElementById('message');
const restartButton = document.getElementById('restartButton');
const flagCount = document.getElementById('flags');

let uncoveredCells = 0;
let data = null;
let colCount = 0;
let rowCount = 0;
let bombCount = 0;
let clickCount = 0;
let flagPlacedCount = 0;

function debugLog() {
    let debugBoard = [];
    for (let rowNumber = 0; rowNumber < rowCount; rowNumber++) {
        debugBoard[rowNumber] = [];
        for (let colNumber = 0; colNumber < colCount; colNumber++) {
            cell = tableBody.rows[rowNumber].cells[colNumber];
            if (isBomb(getNumberForCell(cell))) {
                debugBoard[rowNumber][colNumber] = 'x';
            } else {
                debugBoard[rowNumber][colNumber] = countAdjacentBombs(cell);
            }
        }
    }
    console.log(debugBoard);
    console.log("Rows=" + rowCount +
        " Columns=" + colCount +
        " Bombs=" + bombCount +
        " Clicks=" + clickCount +
        " Uncovered=" + uncoveredCells);
}

function startGame(columns, rows, bombs) {
    flagPlacedCount = 0;
    alive = true;
    colCount = columns;
    rowCount = rows;
    bombCount = bombs;
    clickCount = 0;
    uncoveredCells = 0;

    data = generateData(rowCount, colCount);
    console.log("Starting game with data: ", data);

    while (tableBody.firstChild) {
        tableBody.removeChild(tableBody.firstChild);
    }
    message.textContent = '';
    events.textContent = '';
    flagCount.textContent = 'Currently 0/' + bombCount + ' flags placed 🚩';

    restartButton.addEventListener('click', () => {
        location.reload();
    });

    let index = 0;
    for (let i = 0; i < rowCount; i++) {
        const row = document.createElement('tr');
        for (let j = 0; j < colCount; j++) {
            const cell = document.createElement('td');
            cell.dataset.x = j;
            cell.dataset.y = i;

            cell.textContent = data[index];
            cell.dataset.originalNumber = data[index];
            cell.addEventListener('click', () => {
                handleCellClick(cell);
            });
            cell.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                if (cell.dataset.hasClicked) {
                    return;
                }
                if (cell.textContent === '💣') {
                    return;
                }
                if (cell.textContent === '🚩') {
                    cell.textContent = cell.dataset.originalNumber;
                    cell.style.color = 'transparent';
                    flagPlacedCount--;
                    flagCount.textContent = 'Currently ' + flagPlacedCount + '/' + bombCount + ' flags placed 🚩';
                } else {
                    cell.textContent = '🚩';
                    cell.style.color = '#eeeeee';
                    cell.style.fontSize = '13px';
                    flagPlacedCount++;
                    flagCount.textContent = 'Currently ' + flagPlacedCount + '/' + bombCount + ' flags placed 🚩';
                }
            });

            row.appendChild(cell);
            index++;
        }
        tableBody.appendChild(row);
    }
    debugLog();
}

startGame(14, 14, 40);